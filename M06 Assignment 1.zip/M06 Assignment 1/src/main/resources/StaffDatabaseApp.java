import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StaffDatabaseApp {
    private static final String DB_URL = "jdbc:your-database-url";
    private static final String DB_USER = "your-username";
    private static final String DB_PASSWORD = "your-password";

    public static void main(String[] args) {
        try {
            // Establish a database connection
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // View a record with a specified ID
            int staffIdToView = 1;
            viewStaffRecord(connection, staffIdToView);

            // Insert a new record
            insertStaffRecord(connection);

            // Update a record with a specified ID
            int staffIdToUpdate = 2;
            updateStaffRecord(connection, staffIdToUpdate);

            // Close the database connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewStaffRecord(Connection connection, int staffId) throws SQLException {
        // Create a SQL query to view a staff record
        String query = "SELECT * FROM Staff WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, staffId);

        ResultSet resultSet = preparedStatement.executeQuery();

        // Process and display the result
        while (resultSet.next()) {
            // Retrieve data and print it
            String id = resultSet.getString("id");
            String lastName = resultSet.getString("lastName");
            String firstName = resultSet.getString("firstName");
            // ... (Retrieve other columns)
            System.out.println("ID: " + id);
            System.out.println("Last Name: " + lastName);
            System.out.println("First Name: " + firstName);
            // ... (Print other columns)
        }

        // Close resources
        resultSet.close();
        preparedStatement.close();
    }

    private static void insertStaffRecord(Connection connection) throws SQLException {
        // Create a SQL query to insert a new staff record
        String query = "INSERT INTO Staff (id, lastName, firstName, mi, address, city, state, telephone, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, "new-id");
        preparedStatement.setString(2, "NewLast");
        preparedStatement.setString(3, "NewFirst");
        preparedStatement.setString(4, "N");
        preparedStatement.setString(5, "NewAddress");
        preparedStatement.setString(6, "NewCity");
        preparedStatement.setString(7, "NY");
        preparedStatement.setString(8, "1234567890");
        preparedStatement.setString(9, "new@email.com");

        // Execute the query to insert the record
        int rowsInserted = preparedStatement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("A new staff record was inserted successfully.");
        } else {
            System.out.println("Failed to insert a new staff record.");
        }

        // Close resources
        preparedStatement.close();
    }

    private static void updateStaffRecord(Connection connection, int staffId) throws SQLException {
        // Create a SQL query to update a staff record
        String query = "UPDATE Staff SET lastName = ?, firstName = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, "UpdatedLast");
        preparedStatement.setString(2, "UpdatedFirst");
        preparedStatement.setInt(3, staffId);

        // Execute the query to update the record
        int rowsUpdated = preparedStatement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Staff record with ID " + staffId + " was updated successfully.");
        } else {
            System.out.println("Failed to update staff record with ID " + staffId + ".");
        }

        // Close resources
        preparedStatement.close();
    }
}
